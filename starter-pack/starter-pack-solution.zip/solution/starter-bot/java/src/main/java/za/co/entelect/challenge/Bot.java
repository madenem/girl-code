package za.co.entelect.challenge;

import za.co.entelect.challenge.entities.*;
import za.co.entelect.challenge.enums.BuildingType;
import za.co.entelect.challenge.enums.PlayerType;

import java.util.List;
import java.util.stream.Collectors;

public class Bot {
    private static final String NOTHING_COMMAND = "";
    private GameState gameState;
    private GameDetails gameDetails;
    private int gameWidth;
    private int gameHeight;
    private Player myself;
    private Player opponent;
    private List<Building> buildings;
    private List<Missile> missiles;

    /**
     * Constructor
     *
     * @param gameState the game state
     **/
    public Bot(GameState gameState) {
        this.gameState = gameState;
        gameDetails = gameState.getGameDetails();
        gameWidth = gameDetails.mapWidth;
        gameHeight = gameDetails.mapHeight;
        myself = gameState.getPlayers().stream().filter(p -> p.playerType == PlayerType.A).findFirst().get();
        opponent = gameState.getPlayers().stream().filter(p -> p.playerType == PlayerType.B).findFirst().get();

        buildings = gameState.getGameMap().stream()
                .flatMap(c -> c.getBuildings().stream())
                .collect(Collectors.toList());

        missiles = gameState.getGameMap().stream()
                .flatMap(c -> c.getMissiles().stream())
                .collect(Collectors.toList());
    }

    /**
     * Run
     *
     * @return the result
     **/
    public String run() {
        int round = gameDetails.round;

        if (gameDetails.round == 10) {
            return "0,0,2";
        }

        if(myself.energy >40){
            return "0,1,1";
        }

        if (myself.energy > 30 && round > 50) {
            return "0,2,0";
        }

        for (CellStateContainer cell : gameState.getGameMap()) {
            boolean hasAttack = opponentHasBuilding(BuildingType.ATTACK,
                    cell);
            if (hasAttack) {
                return "1," + cell.y + ",0";
            }
        }
        return doNothing();
    }

    private boolean opponentHasBuilding(BuildingType buildingType, CellStateContainer cell) {
        for (Building building : cell.getBuildings()) {
            if (building.isPlayers(PlayerType.B)
                    && building.buildingType == buildingType) {
                return true;
            }
        }
        return false;
    }

    public String doNothing() {
        return "";
    }
}
